Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/kunda/Desktop/24/pyhton project 24 program.py
20
Enter name:raga
Enter the age:31
Enter the gender:f
Enter food_item name:burger
Enter your rating:4
Enter your opinion:good
Enter name:varsha
Enter the age:21
Enter the gender:f
Enter food_item name:pizza
Enter your rating:5
Enter your opinion:very tasty
Enter name:loki
Enter the age:34
Enter the gender:m
Enter food_item name:fries
Enter your rating:2
Enter your opinion:very salty
Enter name:renu
Enter the age:25
Enter the gender:m
Enter food_item name:chicken rice
Enter your rating:3
Enter your opinion:not bad
Enter name:vyshu
Enter the age:57
Enter the gender:f
Enter food_item name:chicken biryani
Enter your rating:1
Enter your opinion:not satisfied
Enter name:teju
Enter the age:20
Enter the gender:f
Enter food_item name:panner tikka
Enter your rating:5
Enter your opinion:excellent
Enter name:harshith
Enter the age:46
Enter the gender:m
Enter food_item name:shawarma
Enter your rating:4
Enter your opinion:good
Enter name:hema
Enter the age:29
Enter the gender:f
Enter food_item name:manchurian
Enter your rating:2
Enter your opinion:very spicy
Enter name:susmitha
Enter the age:31
Enter the gender:f
Enter food_item name:chicken wings
Enter your rating:4
Enter your opinion:good
Enter name:venkatesh
Enter the age:45
Enter the gender:m
Enter food_item name:prwan biryani
Enter your rating:5
Enter your opinion:satisfied
Enter name:akhila
Enter the age:24
Enter the gender:f
Enter food_item name:kajju pulav
Enter your rating:3
Enter your opinion:better
Enter name:sravanthi
Enter the age:43
Enter the gender:male
Enter food_item name:noddles
Enter your rating:5
Enter your opinion:satisfied
Enter name:yaswanth
Enter the age:32
Enter the gender:m
Enter food_item name:chicken soup
Enter your rating:3
Enter your opinion:avg
Enter name:harini
Enter the age:26
Enter the gender:f
Enter food_item name:chicken fry
Enter your rating:1
Enter your opinion:not satisfied
Enter name:surekha
Enter the age:35
Enter the gender:f
Enter food_item name:veg thalli
Enter your rating:4
Enter your opinion:good
Enter name:mohith
Enter the age:16
Enter the gender:m
Enter food_item name:chicken mandi
Enter your rating:5
Enter your opinion:very tasty
Enter name:maha
Enter the age:43
Enter the gender:f
Enter food_item name:butter naan
Enter your rating:2
Enter your opinion:very bad
Enter name:yagna
Enter the age:29
Enter the gender:f
Enter food_item name:panner mandi
Enter your rating:3
Enter your opinion:better
Enter name:chandra
Enter the age:50
Enter the gender:m
Enter food_item name:frish curry
Enter your rating:5
Enter your opinion:satisfied
Enter name:rohith
Enter the age:25
Enter the gender:m
Enter food_item name:fish fry
Enter your rating:4
Enter your opinion:good taste
         name  age gender        food_item  rating        comment
0        raga   31      f           burger       4           good
1      varsha   21      f            pizza       5     very tasty
2        loki   34      m            fries       2     very salty
3        renu   25      m     chicken rice       3        not bad
4       vyshu   57      f  chicken biryani       1  not satisfied
5        teju   20      f     panner tikka       5      excellent
6    harshith   46      m         shawarma       4           good
7        hema   29      f       manchurian       2     very spicy
8    susmitha   31      f    chicken wings       4           good
9   venkatesh   45      m    prwan biryani       5      satisfied
10     akhila   24      f      kajju pulav       3         better
11  sravanthi   43   male          noddles       5      satisfied
12   yaswanth   32      m     chicken soup       3            avg
13     harini   26      f      chicken fry       1  not satisfied
14    surekha   35      f       veg thalli       4           good
15     mohith   16      m    chicken mandi       5     very tasty
16       maha   43      f      butter naan       2       very bad
17      yagna   29      f     panner mandi       3         better
18    chandra   50      m      frish curry       5      satisfied
19     rohith   25      m         fish fry       4     good taste
Rating less than 3 given by: loki
Rating less than 3 given by: vyshu
Rating less than 3 given by: hema
Rating less than 3 given by: harini
Rating less than 3 given by: maha
Rating more than 3 given by: raga
Rating more than 3 given by: varsha
Rating more than 3 given by: teju
Rating more than 3 given by: harshith
Rating more than 3 given by: susmitha
Rating more than 3 given by: venkatesh
Rating more than 3 given by: sravanthi
Rating more than 3 given by: surekha
Rating more than 3 given by: mohith
Rating more than 3 given by: chandra
Rating more than 3 given by: rohith
Age below 30: varsha
Age below 30: renu
Age below 30: teju
Age below 30: hema
Age below 30: akhila
Age below 30: harini
Age below 30: mohith
Age below 30: yagna
Age below 30: rohith
Age above 30: raga
Age above 30: loki
Age above 30: vyshu
Age above 30: harshith
Age above 30: susmitha
Age above 30: venkatesh
Age above 30: sravanthi
Age above 30: yaswanth
Age above 30: surekha
Age above 30: maha
Age above 30: chandra
how many males: 8
how many females: 11
Persons given rating of 1: 2
persons given rating on 2: 3
persons given rating on 3: 4
persons given rating on 4: 5
persons given rating on 5: 6
older: vyshu
younger: mohith
