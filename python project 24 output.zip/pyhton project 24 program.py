import pandas as pd
s=[]
def add_feedback(name ,age ,gender ,food_item ,rating ,comment):
    feedback={
        'name':name,
        'age':age,
        'gender':gender,
        'food_item':food_item,
        'rating':rating,
        'comment':comment
    }
    s.append(feedback)
n=int(input())
for _ in range(n):
    name=input("Enter name:")
    age=int(input("Enter the age:"))
    gender=input("Enter the gender:")
    food_item=input("Enter food_item name:")
    rating=int(input("Enter your rating:"))
    comment=input("Enter your opinion:")
    add_feedback(name ,age ,gender ,food_item ,rating ,comment)   
'''for i in range(n):
    print(s[i])'''
df=pd.DataFrame(s)
print(df)
for i in range(n):
    if s[i]['rating'] < 3:
        print("Rating less than 3 given by:",s[i]['name'])
for i in range(n):
    if s[i]['rating'] >3:
        print("Rating more than 3 given by:",s[i]['name'])
for i in range(n):
    if s[i]['age'] < 30:
        print("Age below 30:",s[i]['name'])
for i in range(n):
    if s[i]['age'] > 30:
        print("Age above 30:",s[i]['name'])
c1=0
for i in range(n):
    if s[i]['gender'] == 'm':
        c1+=1
print( "how many males:",c1)
c2=0
for i in range(n):
    if s[i]['gender'] == 'f':
        c2+=1
print("how many females:",c2)
c3=0
for i in range(n):
    if s[i]['rating'] == 1 :
        c3+=1
print("Persons given rating of 1:",c3)
c4=0
for i in range(n):
    if s[i]['rating'] == 2:
        c4+=1
print("persons given rating on 2:",c4)
c5=0
for i in range(n):
    if s[i]['rating'] == 3:
        c5+=1
print("persons given rating on 3:",c5)
c6=0
for i in range(n):
    if s[i]['rating'] == 4:
        c6+=1
print("persons given rating on 4:",c6)
c7=0
for i in range(n):
    if s[i]['rating'] == 5:
        c7+=1
print("persons given rating on 5:",c7)
l=[]
for i in range(n):
    l.append(s[i]['age'])

mx=max(l)
mn=min(l)
for i in range(n):
    if s[i]['age']==mx:
        print("older:",s[i]['name'])
    if s[i]['age']==mn:
        print("younger:",s[i]['name'])    
N=input()
for i in range(n):
    if s[i]['name']==N:
        print(s[i]['name'],s[i]['age'],s[i]['gender'],s[i]['food_item'],s[i]['rating'],s[i]['comment'])





